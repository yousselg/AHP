
//dynamic table creation
var matrice = new Array();
var firstTime = 1;
function addNew() {
	var $i = $('#columns').children().length;
	var $critere = $('#critere').val();
	
	if (!$critere.trim()) {
		// is empty or whitespace
		alert("Entrez un critère");
		return;
	}
	$i--;
	
	if(firstTime == 1) {
		$('#cartGrid').removeAttr('hidden');
		firstTime=0;
	}

	//headers
	$('#columns').append("<th scope='row'>" + $critere + "</th>");
	//tbody
	$('#rowExample').append('<tr class="critere"></tr>');
	//add to tr
		$('#rowExample').children().last().append('<th scope="row">' + $critere + '</th>').append("<td data-i=" + $i + " data-j=0><input class='valeur form-control' type='text'  /></td>");
	//each row
	$('#rowExample').children().each(function(index) {
		var $j = 1;
		var $l = $('#columns').children().length;
		var $i = index;
		while ($(this).children().length < $l) {
			$(this).append("<td data-i=" + $i + " data-j=" + $j + "><input class='valeur form-control' type='text' /></td>");
			$j++;
		}
	});
	$('#critere').val("");

	$('#rowExample').children().each(function(i) {
		var tableData = $(this).find('td');
		if (tableData.length > 0) {
			tableData.each(function(j) {
				if (i == j) $(this).children().last().attr('value', '1').attr('disabled', 'true');
			});
		}
	});
}

var myTableArray = [];

function bindToArray() {
	myTableArray = [];

	$("table#cartGrid tr").each(function() {
		var arrayOfThisRow = [];
		var tableData = $(this).find('td');
		if (tableData.length > 0) {
			tableData.each(function() {
				var str = $(this).children().first().val();
				str = str.replace(',','.');
				eval("var answer = "+str);
				arrayOfThisRow.push(answer);
			});
			myTableArray.push(arrayOfThisRow);
		}
	});
}

function calculate() {
	var a = [
		[ 1.00, 7.00000, 5.00000, 3.00000 ],
		[ 0.14, 1.00, 0.33333, 0.20000 ],
		[ 0.20, 3.00, 1.00, 0.25000 ],
		[ 0.33, 5.00, 4.00, 1.00 ]
	];
	bindToArray();
	//	myTableArray
	var object = ahpCalc.calculateResults(myTableArray);
	//headers
	$('#columns').append("<th scope='row' class='success'>Priorité</th>");

	$("#rowExample tr").each(function(i) {
		$(this).append('<td  class="success"><p>' + convertRealToRoundedPercent(object.resultColumn[i]) + '</p></td>');
	});

	$('#resultEiger').html(convertRealToRoundedPercent(object.eigen));
	$('#resultCI').html(convertRealToRoundedPercent(object.consistencyIndex));
	$('#resultCR').html(convertRealToRoundedPercent(object.consistencyRatio));

	if(object.consistencyRatio<0.1)
		$('#resultCRDiv').addClass("alert-success");
	else
		$('#resultCRDiv').addClass("alert-danger");
		
	$('#result').removeAttr("hidden");
	$('#addNew').addClass("disabled");
	$('#critere').attr('disabled','true');
}

function convertRealToRoundedPercent(num, digits) {
	var e = (digits) ? digits : 4;
	var f1 = Math.pow(10, e);

	// rounding will be done by adding half the last digit to last-digit + 1
	// f2 determines the position of last-digit + 1 and r is half the last digit
	var f2 = Math.pow(10, e + 1);
	var r = 5 / f2;

	// calc rounded result
	var resultValue = ((((num + r) * f1) + '').split('.', 1) / f1).toFixed(4);

	// convert to string
	resultValue = resultValue + '';

	return resultValue;
}
;

$(document).ready(function() {
	$('#addNew').click(function() {
		addNew();
	});
	$('#critere').keypress(function(e) {
		if (e.which == 13) addNew();
	});
	$('#calc').click(function() {
		calculate();
	});
});


/********************************************************************/
