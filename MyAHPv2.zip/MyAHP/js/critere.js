
var mesCriteres = new Map();

var info = Object();
info.vercteurPropre = new Array();
info.lambdamax = 0;
info.ic = 0;
info.rc = 0;

var critere = function(nomCritere) {

	var nom = nomCritere;

	var info = Object();

	info.vercteurPropre = new Array();
	info.lambdamax = 0;
	info.ic = 0;
	info.rc = 0;

	info.sousCriteres = new Object();
	info.sousCriteres.criteres = new Array();

	mesCriteres.set(nom, info)

	/*Operations*/
	this.ajouterSousCritere = function(sousCritere) {
		info.sousCriteres.criteres.push(sousCritere);
	}

	this.afficher = function() {
		console.log("Nom : " + nom + " vecteur : " + info.vercteurPropre
			+ " sous cr : " + info.sousCriteres);
	}
}
