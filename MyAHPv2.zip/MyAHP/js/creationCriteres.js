var isFirst = 1;


$(document).ready(function() {
	if (isFirst == 1) {
		
		isFirst = 0;
	}
	$('#ajouterSousCritere').click(function() {
		addSubCrit();
	});

	$('#ajouterCritere').click(function() {
		ajouterCritere();
	});
	$('#finCreation').click(function() {
		finCreation();
	});
});

var firstSub = 1;
function addSubCrit() {
	var canAdd = true;
	$("#subCriterion").removeAttr("hidden");
	if (firstSub == 1) {
		$("#subCriterion").append("<h2>List des sous critères</h2>");
		firstSub = 0
	} else {
		$('.sub').each(function() {
			if (!$(this).val().trim()) {
				alert("Entrer d'abord un sous critère");
				canAdd = false;
			}
		});
	}
	if (canAdd)
		$("#subCriterion").append('<div class="col-xs-4" style="padding-top:2%;"> <input class="form-control sub" id="ex3" type="text" ></div>');
}

function ajouterCritere() {
	var name = $("#critere").val();
	if (!name.trim()) {
		// is empty or whitespace
		alert("Entrez un critère");
		return;
	}
	/* Creation de critère */
	var nvCritere = new critere(name);

	$('.sub').each(function() {
		if (!$(this).val().trim()) {
			// is empty or whitespace
			alert("Entrez un sous critère valide");
			return;
		}
		nvCritere.ajouterSousCritere($(this).val());
	});


	$("#subCriterion").html("");
	$("#critere").val("");
	firstSub = 1;
}

var i = 0;
var j = 1;
var hasChildren;

function finCreation() {
	 ajouterCritere();
	if (mesCriteres.size == 0) return;
	$("#boiteDajout button").each(function() {
		$(this).addClass("disabled");
	});
	$("#boiteDajout input").each(function() {
		$(this).attr("disabled", "true");
	});
	createTable(0, "Les critères");
	for (var [key, value] of mesCriteres) {
		addNew(key, 0);
		if (value.sousCriteres.criteres.length > 0) {
			createTable(j, "les sous critères de : " + key);
			for (var sc of value.sousCriteres.criteres)
				addNew(sc, j);
		}
		if (value.sousCriteres.criteres.length > 0) j++; }

}