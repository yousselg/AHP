
//dynamic table creation
var matrice = new Array();
var firstTime = 1;

//[data-id='+i+']

function createTable(ind,name) {
	$("#example").clone().attr('id', 'example' + ind).insertBefore("#example");

	$("#example" + ind + " table").attr('data-id', 'cartGrid' + ind);
	$("#example" + ind + " tr").attr('data-id', 'columns' + ind);
	$("#example" + ind + " tbody").attr('data-id', 'rowExample' + ind);
	$("#example" + ind + " .calc").attr('data-i', ind);

	$("#example" + ind + " #result").attr('id', "result" + ind);
	$("#example" + ind + " #resultEiger").attr('id', "resultEiger" + ind);
	$("#example" + ind + " #resultCI").attr('id', "resultCI" + ind);
	$("#example" + ind + " #resultCRDiv").attr('id', "resultCRDiv" + ind);
	$("#example" + ind + " #resultCR").attr('id', "resultCR" + ind);
	$("#example" + ind + " #title").html(name);

	$("#example" + ind).removeAttr("hidden");

	$('.calc').click(function() {
		
		calculate($(this).attr("data-i"));
	});
}

function addNew(nom, ind) {
	var $i = $('[data-id=columns' + ind + ']').children().length;
	var $critere = nom;

	if (!$critere.trim()) {
		// is empty or whitespace
		alert("Entrez un critère");
		return;
	}
	$i--;

	$('[data-id=cartGrid' + ind + ']').removeAttr('hidden');


	//headers
	$('[data-id=columns' + ind + ']').append("<th scope='row'>" + $critere + "</th>");
	//tbody
	$('[data-id=rowExample' + ind + ']').append('<tr class="critere"></tr>');
	//add to tr
	$('[data-id=rowExample' + ind + ']').children().last().append('<th scope="row">' + $critere + '</th>').append("<td data-i=" + $i + " data-j=0><input class='valeur form-control' type='text'  /></td>");
	//each row
	$('[data-id=rowExample' + ind + ']').children().each(function(index) {
		var $j = 1;
		var $l = $('[data-id=columns' + ind + ']').children().length;
		var $i = index;
		while ($(this).children().length < $l) {
			$(this).append("<td data-i=" + $i + " data-j=" + $j + "><input class='valeur form-control' type='text' /></td>");
			$j++;
		}
	});
	$('#critere').val("");

	$('[data-id=rowExample' + ind + ']').children().each(function(i) {
		var tableData = $(this).find('td');
		if (tableData.length > 0) {
			tableData.each(function(j) {
				if (i == j) $(this).children().last().attr('value', '1').attr('disabled', 'true');
			});
		}
	});
}

var myTableArray = [];

function bindToArray(i) {
	myTableArray = [];

	$("[data-id=cartGrid" + i + "] tr").each(function() {
		var arrayOfThisRow = [];
		var tableData = $(this).find('td');
		if (tableData.length > 0) {
			tableData.each(function() {
				var str = $(this).children().first().val();
				str = str.replace(',', '.');
				eval("var answer = " + str);
				arrayOfThisRow.push(answer);
			});
			myTableArray.push(arrayOfThisRow);
		}
	});
}

function calculate(ind) {
	var a = [
		[ 1.00, 7.00000, 5.00000, 3.00000 ],
		[ 0.14, 1.00, 0.33333, 0.20000 ],
		[ 0.20, 3.00, 1.00, 0.25000 ],
		[ 0.33, 5.00, 4.00, 1.00 ]
	];
	bindToArray(ind);
	//	myTableArray
	var object = ahpCalc.calculateResults(myTableArray);
	//headers
	$('[data-id=columns' + ind + ']').append("<th scope='row' class='success'>Priorité</th>");

	$('[data-id=rowExample' + ind + '] tr').each(function(i) {
		$(this).append('<td  class="success"><p>' + convertRealToRoundedPercent(object.resultColumn[i]) + '</p></td>');
	});

	$('#resultEiger' + ind).html(convertRealToRoundedPercent(object.eigen));
	$('#resultCI' + ind).html(convertRealToRoundedPercent(object.consistencyIndex));
	$('#resultCR' + ind).html(convertRealToRoundedPercent(object.consistencyRatio));

	/************ bloc storing results **********/
	var indexOfSc = 0;

	if (ind == 0) {
		info.vercteurPropre = object.resultColumn.slice();
		info.lambdamax = object.eigen;
		info.ic = object.consistencyIndex;
		info.rc = object.consistencyRatio;
	}
	else
		for (var [key, value] of mesCriteres) {
			if (indexOfSc == ind) {
				value.vercteurPropre = object.resultColumn.slice();
				;
				value.lambdamax = object.eigen;
				value.ic = object.consistencyIndex;
				value.rc = object.consistencyRatio;
			}
			else indexOfSc++; }
			/************ End bloc storing results **********/

	if (object.consistencyRatio < 0.1)
		$('#resultCRDiv' + ind).addClass("alert-success");
	else
		$('#resultCRDiv' + ind).addClass("alert-danger");

	$('#result' + ind).removeAttr("hidden");
	$('#addNew').addClass("disabled");
	$('#critere').attr('disabled', 'true');
}

function convertRealToRoundedPercent(num, digits) {
	var e = (digits) ? digits : 4;
	var f1 = Math.pow(10, e);

	// rounding will be done by adding half the last digit to last-digit + 1
	// f2 determines the position of last-digit + 1 and r is half the last digit
	var f2 = Math.pow(10, e + 1);
	var r = 5 / f2;

	// calc rounded result
	var resultValue = ((((num + r) * f1) + '').split('.', 1) / f1).toFixed(4);

	// convert to string
	resultValue = resultValue + '';

	return resultValue;
}
;

$(document).ready(function() {
	$('#addNew').click(function() {
		addNew();
	});
	$('#critere').keypress(function(e) {
		if (e.which == 13) addNew();
	});



});


/********************************************************************/